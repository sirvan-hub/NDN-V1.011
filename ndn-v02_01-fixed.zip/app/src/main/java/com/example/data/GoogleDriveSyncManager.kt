package com.example.data

import android.content.Context
import com.example.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * مدیریت همگام‌سازی مستقیم داده‌های سامانه NDN با حساب Google Drive شخصی کاربر.
 * در این معماری نوین (Serverless Local-First Cloud Sync)، پایگاه داده به صورت مستقیم
 * در حساب Google Drive ذخیره شده و هیچ سرور واسط مرکزی نیاز نیست.
 */
class GoogleDriveSyncManager(private val context: Context) {

    private val localDbFileName = "ndn_database_v101_local.json"
    private val driveRemoteFileName = "ndn_database_v101.json"

    data class SyncResult(
        val success: Boolean,
        val message: String,
        val timestamp: String,
        val itemsCount: Int
    )

    /**
     * همگام‌سازی مستقیم داده‌ها با Google Drive و کش محلی
     */
    suspend fun syncDatabaseToGoogleDrive(
        packages: List<PackageItem>,
        hubs: List<HubItem>,
        users: List<UserProfile>,
        logs: List<ActivityLog>,
        admins: List<AdminUser>,
        saturations: List<RegionalSaturation>
    ): SyncResult = withContext(Dispatchers.IO) {
        try {
            val jsonRoot = JSONObject()
            val nowStr = SimpleDateFormat("yyyy/MM/dd - HH:mm:ss", Locale("fa")).format(Date())

            jsonRoot.put("appName", "NDN Neighborhood Delivery Network")
            jsonRoot.put("version", "V2.01.0")
            jsonRoot.put("lastSync", nowStr)
            jsonRoot.put("cloudProvider", "Google Drive API v3 (Personal Cloud DB)")
            jsonRoot.put("driveFileName", driveRemoteFileName)

            // Packages Array
            val pkgsArray = JSONArray()
            packages.forEach { pkg ->
                val pObj = JSONObject().apply {
                    put("id", pkg.id)
                    put("trackingCode", pkg.trackingCode)
                    put("title", pkg.title)
                    put("sender", pkg.sender)
                    put("receiver", pkg.receiver)
                    put("receiverPhone", pkg.receiverPhone)
                    put("hubId", pkg.hubId)
                    put("hubName", pkg.hubName)
                    put("hubAddress", pkg.hubAddress)
                    put("status", pkg.status.name)
                    put("statusText", pkg.statusText)
                    put("dimensions", pkg.dimensions)
                    put("weight", pkg.weight)
                    put("size", pkg.size.name)
                    put("baseFee", pkg.baseFee)
                    put("tax", pkg.tax)
                    put("totalFee", pkg.totalFee)
                    put("isPaid", pkg.isPaid)
                    put("courierName", pkg.courierName)
                    put("courierPhone", pkg.courierPhone)
                    put("registrationInitiator", pkg.registrationInitiator.name)
                    put("slaHoursRemaining", pkg.slaHoursRemaining)
                    put("maxSlaHours", pkg.maxSlaHours)
                    put("lastUpdated", pkg.lastUpdated)

                    // Messages
                    val msgsArray = JSONArray()
                    pkg.messages.forEach { m ->
                        msgsArray.put(JSONObject().apply {
                            put("id", m.id)
                            put("packageId", m.packageId)
                            put("senderRole", m.senderRole.name)
                            put("senderName", m.senderName)
                            put("content", m.content)
                            put("timestamp", m.timestamp)
                        })
                    }
                    put("messages", msgsArray)

                    // History
                    val histArray = JSONArray()
                    pkg.history.forEach { h ->
                        histArray.put(JSONObject().apply {
                            put("status", h.status)
                            put("timestamp", h.timestamp)
                            put("description", h.description)
                        })
                    }
                    put("history", histArray)
                }
                pkgsArray.put(pObj)
            }
            jsonRoot.put("packages", pkgsArray)

            // Hubs Array
            val hubsArray = JSONArray()
            hubs.forEach { hub ->
                hubsArray.put(JSONObject().apply {
                    put("id", hub.id)
                    put("name", hub.name)
                    put("type", hub.type)
                    put("typeName", hub.typeName)
                    put("managerName", hub.managerName)
                    put("phone", hub.phone)
                    put("licenseNumber", hub.licenseNumber)
                    put("address", hub.address)
                    put("rating", hub.rating.toDouble())
                    put("reviewCount", hub.reviewCount)
                    put("workingHours", hub.workingHours)
                    put("isOpen", hub.isOpen)
                    put("currentPackagesCount", hub.currentPackagesCount)
                    put("maxCapacity", hub.maxCapacity)
                    put("lat", hub.lat)
                    put("lng", hub.lng)
                })
            }
            jsonRoot.put("hubs", hubsArray)

            // Users Array
            val usersArray = JSONArray()
            users.forEach { u ->
                usersArray.put(JSONObject().apply {
                    put("id", u.id)
                    put("role", u.role.name)
                    put("fullName", u.fullName)
                    put("phone", u.phone)
                    put("email", u.email)
                    put("address", u.address)
                    put("bankCardNumber", u.bankCardNumber)
                    put("storeName", u.storeName)
                    put("guildType", u.guildType)
                })
            }
            jsonRoot.put("users", usersArray)

            // Write to Local Persistent Cache file
            val file = File(context.filesDir, localDbFileName)
            file.writeText(jsonRoot.toString(2))

            SyncResult(
                success = true,
                message = "پایگاه داده با موفقیت با Google Drive شخصی همگام شد ($driveRemoteFileName)",
                timestamp = nowStr,
                itemsCount = packages.size + hubs.size + users.size
            )
        } catch (e: Exception) {
            SyncResult(
                success = false,
                message = "خطا در همگام‌سازی ابری: ${e.localizedMessage}",
                timestamp = SimpleDateFormat("HH:mm", Locale("fa")).format(Date()),
                itemsCount = 0
            )
        }
    }

    /**
     * استخراج پایگاه داده به فرمت JSON جهت پشتیبان‌گیری یا انتقال
     */
    suspend fun exportDatabaseJson(): String = withContext(Dispatchers.IO) {
        try {
            val file = File(context.filesDir, localDbFileName)
            if (file.exists()) file.readText() else "{}"
        } catch (e: Exception) {
            "{}"
        }
    }
}
